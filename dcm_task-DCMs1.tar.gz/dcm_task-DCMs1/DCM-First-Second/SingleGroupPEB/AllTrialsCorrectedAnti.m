%-----------------------------------------------------------------------
% Job saved on 20-Feb-2022 22:42:21 by cfg_util (rev $Rev: 6942 $)
% spm SPM - Unknown
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.dcm.peb.specify.name = 'AllTrialsCorrectedAnti';
matlabbatch{1}.spm.dcm.peb.specify.model_space_mat = {'GCMAllTrialsCorrectedAnti.mat'};
matlabbatch{1}.spm.dcm.peb.specify.dcm.index = 1;
matlabbatch{1}.spm.dcm.peb.specify.cov.none = struct([]);
matlabbatch{1}.spm.dcm.peb.specify.fields.default = {
                                                     'A'
                                                     'B'
                                                     }';
matlabbatch{1}.spm.dcm.peb.specify.priors_between.ratio = 16;
matlabbatch{1}.spm.dcm.peb.specify.priors_between.expectation = 0;
matlabbatch{1}.spm.dcm.peb.specify.priors_between.var = 0.0625;
matlabbatch{1}.spm.dcm.peb.specify.priors_glm.group_ratio = 1;
matlabbatch{1}.spm.dcm.peb.specify.show_review = 0;
